<?php
/**
 * Plugin Name: Product Features Repeater (SVG + Media Upload + Fallback)
 * Description: Repeater text fields for WooCommerce products with custom icons (media/SVG/fallback).
 * Version: 1.5
 * Author: Krishna
 * Author Url : <www class="krishnasu com"></www>
 */

/* -----------------------------
  Allow SVG Uploads
----------------------------- */
add_filter('upload_mimes', function ($mimes) {
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
});

/* -----------------------------
  Add Meta Box
----------------------------- */
add_action('add_meta_boxes', function () {
    add_meta_box(
        'pfr_box',
        'Product Features (Repeater with Icon)',
        'pfr_box_html',
        'product',
        'normal',
        'high'
    );
});

/* Meta Box HTML */
function pfr_box_html($post)
{
    $features = get_post_meta($post->ID, '_pfr_features', true);
    if (!is_array($features)) $features = [];

    wp_nonce_field('pfr_save_data', 'pfr_nonce');
    wp_enqueue_media(); // For media uploader
    ?>
    <div id="pfr-repeater">
        <button type="button" class="button" id="pfr-add">+ Add Feature</button>
        <p>Each feature can have its own icon: media (PNG/JPG/SVG) or paste inline SVG, or fallback char.</p>
        <div id="pfr-items">
            <?php foreach ($features as $feature):
                $text = $feature['text'] ?? '';
                $icon_type = $feature['icon_type'] ?? 'char';
                $icon_media = $feature['icon_media'] ?? '';
                $icon_svg = $feature['icon_svg'] ?? '';
                $icon_char = $feature['icon_char'] ?? '✔';
                ?>
                <div class="pfr-row" style="border:1px solid #eee;padding:10px;margin-bottom:10px;">
                    <label>Feature text</label><br>
                    <input type="text" name="pfr_features[][text]" value="<?php echo esc_attr($text); ?>" style="width:70%"><br><br>

                    <label>Icon type</label><br>
                    <select name="pfr_features[][icon_type]" class="pfr-icon-type">
                        <option value="char" <?php selected($icon_type, 'char'); ?>>Character (fallback)</option>
                        <option value="media" <?php selected($icon_type, 'media'); ?>>Media (image/SVG file)</option>
                        <option value="svg" <?php selected($icon_type, 'svg'); ?>>Inline SVG (paste code)</option>
                    </select>

                    <div class="pfr-media-wrap" style="margin-top:8px; <?php echo ($icon_type=='media')?'':'display:none'; ?>">
                        <button type="button" class="button pfr-upload-btn">Select / Upload Icon</button>
                        <input type="hidden" name="pfr_features[][icon_media]" value="<?php echo esc_attr($icon_media); ?>">
                        <div class="pfr-media-preview" style="margin-top:8px;">
                            <?php
                            if ($icon_media) {
                                $url = wp_get_attachment_url($icon_media);
                                if ($url) {
                                    echo '<img src="'.esc_url($url).'" style="max-width:80px;display:block;">';
                                } else {
                                    $fallback_url = plugin_dir_url(__FILE__).'assets/img/fallback.png';
                                    echo '<img src="'.esc_url($fallback_url).'" style="max-width:80px;display:block;">';
                                }
                            }
                            ?>
                        </div>
                    </div>

                    <div class="pfr-svg-wrap" style="margin-top:8px; <?php echo ($icon_type=='svg')?'':'display:none'; ?>">
                        <label>Paste SVG code</label><br>
                        <textarea name="pfr_features[][icon_svg]" rows="4" style="width:70%;"><?php echo esc_textarea($icon_svg); ?></textarea>
                        <small>SVG will output inline (careful with untrusted SVG).</small>
                    </div>

                    <div class="pfr-char-wrap" style="margin-top:8px; <?php echo ($icon_type=='char')?'':'display:none'; ?>">
                        <label>Character (fallback)</label><br>
                        <input type="text" name="pfr_features[][icon_char]" value="<?php echo esc_attr($icon_char); ?>" style="width:70px;">
                    </div>
                    <br>
                    <button type="button" class="button pfr-remove">Remove</button>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script>
    document.addEventListener("DOMContentLoaded", function(){
        const addBtn = document.getElementById("pfr-add");
        const items = document.getElementById("pfr-items");

        addBtn.addEventListener("click", function(){
            const html = `<div class="pfr-row" style="border:1px solid #eee;padding:10px;margin-bottom:10px;">
                <label>Feature text</label><br>
                <input type="text" name="pfr_features[][text]" value="" style="width:70%"><br><br>
                <label>Icon type</label><br>
                <select name="pfr_features[][icon_type]" class="pfr-icon-type">
                    <option value="char">Character (fallback)</option>
                    <option value="media">Media (image/SVG file)</option>
                    <option value="svg">Inline SVG (paste code)</option>
                </select>
                <div class="pfr-media-wrap" style="margin-top:8px; display:none;">
                    <button type="button" class="button pfr-upload-btn">Select / Upload Icon</button>
                    <input type="hidden" name="pfr_features[][icon_media]" value="">
                    <div class="pfr-media-preview" style="margin-top:8px;">
                        <img src="<?php echo plugin_dir_url(__FILE__).'assets/img/fallback.png'; ?>" style="max-width:80px;display:block;">
                    </div>
                </div>
                <div class="pfr-svg-wrap" style="margin-top:8px; display:none;">
                    <textarea name="pfr_features[][icon_svg]" rows="4" style="width:70%;"></textarea>
                </div>
                <div class="pfr-char-wrap" style="margin-top:8px;">
                    <input type="text" name="pfr_features[][icon_char]" value="✔" style="width:70px;">
                </div>
                <br><button type="button" class="button pfr-remove">Remove</button>
            </div>`;
            items.insertAdjacentHTML('beforeend', html);
        });

        document.addEventListener("click", function(e){
            if(e.target.classList.contains("pfr-remove")){
                e.target.closest('.pfr-row').remove();
            }
            if(e.target.classList.contains("pfr-upload-btn")){
                const btn = e.target;
                const row = btn.closest('.pfr-row');
                const preview = row.querySelector('.pfr-media-preview');
                const input = row.querySelector('input[type="hidden"]');

                let frame = wp.media({
                    title:'Select Icon',
                    library:{type:['image','image/svg+xml']},
                    multiple:false
                });

                frame.on('select', function(){
                    let attachment = frame.state().get('selection').first().toJSON();
                    input.value = attachment.id;
                    preview.innerHTML = '<img src="'+attachment.url+'" style="max-width:80px;display:block;">';
                });

                frame.open();
            }
        });

        document.addEventListener("change", function(e){
            if(e.target.classList.contains("pfr-icon-type")){
                const row = e.target.closest('.pfr-row');
                const type = e.target.value;
                row.querySelector('.pfr-media-wrap').style.display = (type==='media')?'':'none';
                row.querySelector('.pfr-svg-wrap').style.display = (type==='svg')?'':'none';
                row.querySelector('.pfr-char-wrap').style.display = (type==='char')?'':'none';
            }
        });
    });
    </script>
    <?php
}

/* -----------------------------
  Save Meta Data
----------------------------- */
add_action('save_post_product', function($post_id){
    if(!isset($_POST['pfr_nonce']) || !wp_verify_nonce($_POST['pfr_nonce'],'pfr_save_data')) return;

    if(isset($_POST['pfr_features']) && is_array($_POST['pfr_features'])){
        $cleaned=[];
        foreach($_POST['pfr_features'] as $row){
            $text = sanitize_text_field($row['text'] ?? '');
            $icon_type = in_array($row['icon_type'] ?? 'char',['char','media','svg']) ? $row['icon_type']:'char';
            $icon_media = isset($row['icon_media'])?intval($row['icon_media']):'';
            $icon_svg = $row['icon_svg'] ?? '';
            $icon_char = sanitize_text_field($row['icon_char'] ?? '✔');
            if($text==='') continue;
            $cleaned[] = compact('text','icon_type','icon_media','icon_svg','icon_char');
        }
        update_post_meta($post_id,'_pfr_features',$cleaned);
    } else {
        delete_post_meta($post_id,'_pfr_features');
    }
});

/* -----------------------------
  Frontend Shortcode
----------------------------- */
add_shortcode('product_features', function(){
    global $post;
    if(!$post) return '';

    $features = get_post_meta($post->ID,'_pfr_features',true);
    if(empty($features) || !is_array($features)) return '';

    $fallback_url = plugin_dir_url(__FILE__).'assets/img/fallback.png';

    $out = '<ul class="product-features">';
    foreach($features as $f){
        $text = esc_html($f['text'] ?? '');
        $icon_html = '';

        // MEDIA icon (PNG/JPG/SVG)
        if(($f['icon_type']??'char')==='media' && !empty($f['icon_media'])){
            $url = wp_get_attachment_url($f['icon_media']);
            if(!$url) $url = $fallback_url;
            $icon_html = '<img src="'.esc_url($url).'" style="width:18px;height:18px;margin-right:8px;">';
        }
        // INLINE SVG
        elseif(($f['icon_type']??'char')==='svg' && !empty($f['icon_svg'])){
            $raw_svg = trim($f['icon_svg']);
            if(strpos($raw_svg,'<svg')!==false){
                $raw_svg = preg_replace('/<svg(.*?)>/', '<svg$1 width="18" height="18">', $raw_svg);
                $icon_html='<span class="pf-svg-icon" style="display:inline-block;margin-right:8px;line-height:0;">'.$raw_svg.'</span>';
            } else {
                $icon_html = '<img src="'.esc_url($fallback_url).'" style="width:18px;height:18px;margin-right:8px;">';
            }
        }
        // CHAR fallback
        else{
            $char = esc_html($f['icon_char'] ?? '✔');
            $icon_html='<span class="pf-icon-char" style="display:inline-block;width:18px;height:18px;background:#e91e63;color:#fff;border-radius:50%;text-align:center;font-size:12px;margin-right:8px;line-height:18px;">'.$char.'</span>';
        }

        $out.='<li class="pf-item">'.$icon_html.'<span class="pf-text">'.$text.'</span></li>';
    }
    $out.='</ul>';

    $out.='<style>
    .product-features{list-style:none;padding:0;margin:0;display:grid;grid-template-columns:repeat(2,1fr);gap:10px 20px;}
    .product-features li{display:flex;align-items:flex-start;font-size:16px;color:#000;line-height:1.4;}
    .pf-img-icon{width:18px;height:18px;object-fit:contain;}
    .pf-svg-icon svg{width:18px;height:18px;display:block;}
    .pf-icon-char{background:#e91e63;color:#fff;border-radius:50%;width:18px;height:18px;text-align:center;font-size:12px;margin-right:8px;line-height:18px;}
    .pf-text{display:inline-block;}
    </style>';

    return $out;
});
